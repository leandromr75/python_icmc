# Material complementar


- Operações em sequências: [https://docs.python.org/3/library/stdtypes.html#typesseq](https://docs.python.org/3/library/stdtypes.html#typesseq)

- Funções padrão: [https://docs.python.org/3/library/functions.html] (https://docs.python.org/3/library/functions.html)

- Classes: [https://docs.python.org/3/tutorial/classes.html] (https://docs.python.org/3/tutorial/classes.html)

- Exceções padrão: [https://docs.python.org/3/tutorial/errors.html](https://docs.python.org/3/tutorial/errors.html)

- Mais sobre leitura e escrita de dados: [https://docs.python.org/3/tutorial/inputoutput.html](https://docs.python.org/3/tutorial/inputoutput.html)

